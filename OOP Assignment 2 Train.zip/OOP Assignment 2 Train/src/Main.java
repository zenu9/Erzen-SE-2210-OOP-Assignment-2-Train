import kz.railway.Info;
import kz.railway.trains.*;
import kz.railway.wagons.Wagon;
import kz.railway.wagons.cargo.Grocery;
import kz.railway.wagons.cargo.Manufacture;
import kz.railway.wagons.cargo.Parcel;
import kz.railway.wagons.passenger.Compartment;
import kz.railway.wagons.passenger.Luxury;
import kz.railway.wagons.passenger.Reserved;
import kz.railway.wagons.passenger.Sedentary;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome to the Kazakhstan railway!");

        Info info = new Info();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while(running) {
            System.out.println("Trip: Astana -> Almaty");
            System.out.println("What do you want to do?");
            System.out.println("""
                    0 - Exit
                    1 - Buy ticket
                    2 - Send goods
                    """);

            System.out.print("Input: ");
            int input = scanner.nextInt();

            if(input == 0) {
                System.out.println("Exit!");
                running = false;
            }
            if(input == 1) {
                System.out.println("Enter your full name:");
                String fullName = scanner.nextLine();
                scanner.nextLine();
                System.out.println("Enter your age:");
                int age = scanner.nextInt();
                info.showTrains();
                System.out.print("Input: ");
                int chooseTrain = scanner.nextInt();
                if(chooseTrain == 1) {
                    info.showWagons();
                    System.out.print("Input: ");
                    int chooseWagon = scanner.nextInt();
                    if (chooseWagon == 1) {
                        Wagon wagon = new Compartment();
                        Train train = new Branded(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                    if (chooseWagon == 2) {
                        Wagon wagon = new Luxury();
                        Train train = new Branded(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                    if (chooseWagon == 3) {
                        Wagon wagon = new Reserved();
                        Train train = new Branded(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                    if (chooseWagon == 4) {
                        Wagon wagon = new Sedentary();
                        Train train = new Branded(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                }
                if(chooseTrain == 2) {
                    info.showWagons();
                    System.out.print("Input: ");
                    int chooseWagon = scanner.nextInt();
                    if (chooseWagon == 1) {
                        Wagon wagon = new Compartment();
                        Train train = new Fast(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                    if (chooseWagon == 2) {
                        Wagon wagon = new Luxury();
                        Train train = new Fast(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                    if (chooseWagon == 3) {
                        Wagon wagon = new Reserved();
                        Train train = new Fast(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                    if (chooseWagon == 4) {
                        Wagon wagon = new Sedentary();
                        Train train = new Fast(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                }
                if(chooseTrain == 3) {
                    info.showWagons();
                    System.out.print("Input: ");
                    int chooseWagon = scanner.nextInt();
                    if (chooseWagon == 1) {
                        Wagon wagon = new Compartment();
                        Train train = new PassengersTrain(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                    if (chooseWagon == 2) {
                        Wagon wagon = new Luxury();
                        Train train = new PassengersTrain(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                    if (chooseWagon == 3) {
                        Wagon wagon = new Reserved();
                        Train train = new PassengersTrain(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                    if (chooseWagon == 4) {
                        Wagon wagon = new Sedentary();
                        Train train = new PassengersTrain(wagon);
                        System.out.println("Choose your place:");
                        int place = scanner.nextInt();
                        wagon.freePlaces[place] = false;
                    }
                }
            }
            if(input == 2) {
                System.out.println("Enter your full name:");
                String fullName = scanner.nextLine();
                scanner.nextLine();
                System.out.println("Enter your age:");
                int age = scanner.nextInt();
                info.showProducts();
                System.out.print("Input: ");
                int choice = scanner.nextInt();
                if(choice == 1) {
                    Wagon wagon = new Grocery();
                    Train train = new FreightTrain(wagon);
                }
                if(choice == 2) {
                    Wagon wagon = new Parcel();
                    Train train = new FreightTrain(wagon);
                }
                if(choice == 3) {
                    Wagon wagon = new Manufacture();
                    Train train = new FreightTrain(wagon);
                }
            }
        }
    }
}