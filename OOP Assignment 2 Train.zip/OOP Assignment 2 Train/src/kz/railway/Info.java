package kz.railway;

public class Info {
    public void showTrains() {
        System.out.println("""
                        Which train do you want to go with?
                        1 - Branded
                        2 - Fast
                        3 - Passenger
                        """);
    }
    public void showWagons() {
        System.out.println("""
                        Which wagon do you want to go with?
                        1 - Compartment
                        2 - Luxury
                        3 - Reserved
                        4 - Sedentary
                        """);
    }
    public void showProducts() {
        System.out.println("""
                        What kind of product do you want to send?
                        1 - Foodstuffs
                        2 - Package
                        3 - Manufactured goods
                        """);
    }
}
