package kz.railway;

public class Passenger {
    private String fullName;
    private int age;

    public Passenger(String fullName, int age){
        setFullName(fullName);
        setAge(age);
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getFullName() {
        return fullName;
    }
}
