package kz.railway.locomotive;

public class Electric extends Locomotive {
    private double maxSpeed = 150;
    private int wagonTraction = 30;

    @Override
    public String getInfoL() {
        return "(Locomotive: Electric)";
    }
}
