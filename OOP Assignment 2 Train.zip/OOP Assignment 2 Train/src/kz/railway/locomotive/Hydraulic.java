package kz.railway.locomotive;

public class Hydraulic extends Locomotive {
    private double maxSpeed = 90;
    private int wagonTraction = 30;

    @Override
    public String getInfoL() {
        return "(Locomotive: Hydraulic)";
    }
}
