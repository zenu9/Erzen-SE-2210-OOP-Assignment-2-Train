package kz.railway.locomotive;

public class Locomotive {
    private double maxSpeed = 100;
    private int wagonTraction = 20;

    public String getInfoL() {
        return "Locomotive";
    }
}
