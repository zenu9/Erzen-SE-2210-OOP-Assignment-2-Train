package kz.railway.locomotive;

public class Mechanical extends Locomotive {
    private double maxSpeed = 120;
    private int wagonTraction = 24;

    @Override
    public String getInfoL() {
        return "(Locomotive: Mechanical)";
    }
}
