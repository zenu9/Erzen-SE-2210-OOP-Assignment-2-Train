package kz.railway.trains;

import kz.railway.locomotive.Electric;
import kz.railway.wagons.Wagon;

public class Branded extends Train {
    public int amountOfWagons = 10;
    public Branded(Wagon wagon) {
        super(wagon);
        this.locomotive = new Electric();
    }
    @Override
    public String getInfo() {
        return "Branded Train";
    }
}
