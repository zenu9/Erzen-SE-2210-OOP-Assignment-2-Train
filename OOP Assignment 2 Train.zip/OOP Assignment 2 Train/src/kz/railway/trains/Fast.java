package kz.railway.trains;

import kz.railway.locomotive.Mechanical;
import kz.railway.wagons.Wagon;

public class Fast extends Train {
    public int amountOfWagons = 7;
    public Fast(Wagon wagon) {
        super(wagon);
        this.locomotive = new Mechanical();
    }
    @Override
    public String getInfo() {
        return "Fast Train";
    }
}
