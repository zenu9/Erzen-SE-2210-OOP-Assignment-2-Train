package kz.railway.trains;

import kz.railway.locomotive.Mechanical;
import kz.railway.wagons.Wagon;

public class FreightTrain extends Train {
    public FreightTrain(Wagon wagon) {
        super(wagon);
        this.locomotive = new Mechanical();
    }
    @Override
    public String getInfo() {
        return "Freight Train";
    }
}
