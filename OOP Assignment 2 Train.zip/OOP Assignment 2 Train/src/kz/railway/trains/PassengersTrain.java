package kz.railway.trains;

import kz.railway.locomotive.Hydraulic;
import kz.railway.wagons.Wagon;

public class PassengersTrain extends Train {
    public int amountOfWagons = 15;
    public PassengersTrain(Wagon wagon) {
        super(wagon);
        this.locomotive = new Hydraulic();
    }
    @Override
    public String getInfo() {
        return "Passengers Train";
    }
}
