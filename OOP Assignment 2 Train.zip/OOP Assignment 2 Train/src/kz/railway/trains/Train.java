package kz.railway.trains;

import kz.railway.locomotive.Locomotive;
import kz.railway.wagons.Wagon;

public class Train extends Locomotive {
    public Locomotive locomotive;
    public Wagon wagon;
    public int amountOfWagons = 5;
    public Train(Wagon wagon) {
        this.wagon = wagon;
        this.locomotive = new Locomotive();
    }
    public String getInfo() {
        return "Train";
    };
}
