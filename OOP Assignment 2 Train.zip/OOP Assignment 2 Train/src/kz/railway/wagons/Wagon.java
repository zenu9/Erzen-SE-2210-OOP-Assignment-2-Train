package kz.railway.wagons;

public class Wagon {
    public int places;
    public double capacity;
    public boolean[] freePlaces;

    public String getInfoW() {
        return "Wagon";
    }
}
