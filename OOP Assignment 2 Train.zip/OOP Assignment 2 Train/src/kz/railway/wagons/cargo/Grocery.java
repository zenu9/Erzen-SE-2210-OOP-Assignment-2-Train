package kz.railway.wagons.cargo;

import kz.railway.wagons.Wagon;

public class Grocery extends Wagon {
    public double capacity = 120;

    @Override
    public String getInfoW() {
        return "Grocery Wagon";
    }
}
