package kz.railway.wagons.cargo;

import kz.railway.wagons.Wagon;

public class Manufacture extends Wagon {
    public double capacity = 200;
    @Override
    public String getInfoW() {
        return "Wagon for Manufactures";
    }
}
