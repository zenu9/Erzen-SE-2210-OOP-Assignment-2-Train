package kz.railway.wagons.cargo;

import kz.railway.wagons.Wagon;

public class Parcel extends Wagon {
    public double capacity = 150;

    @Override
    public String getInfoW() {
        return "Parcel Wagon";
    }
}
