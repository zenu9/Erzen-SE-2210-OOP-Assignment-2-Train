package kz.railway.wagons.passenger;

import kz.railway.wagons.Wagon;

public class Compartment extends Wagon {
    public int places = 36;
    public boolean[] freePlaces = new boolean[places];

    @Override
    public String getInfoW() {
        return "Compartment Wagon";
    }
}
