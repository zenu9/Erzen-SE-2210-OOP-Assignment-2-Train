package kz.railway.wagons.passenger;

import kz.railway.wagons.Wagon;

public class Luxury extends Wagon {
    public int places = 18;
    public boolean[] freePlaces = new boolean[places];

    @Override
    public String getInfoW() {
        return "Luxury Wagon";
    }
}
