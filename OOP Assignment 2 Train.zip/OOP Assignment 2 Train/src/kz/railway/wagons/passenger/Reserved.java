package kz.railway.wagons.passenger;

import kz.railway.wagons.Wagon;

public class Reserved extends Wagon {
    public int places = 54;
    public boolean[] freePlaces = new boolean[places];

    @Override
    public String getInfoW() {
        return "Reserved Wagon";
    }
}
