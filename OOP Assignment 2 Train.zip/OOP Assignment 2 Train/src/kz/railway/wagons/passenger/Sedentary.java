package kz.railway.wagons.passenger;

import kz.railway.wagons.Wagon;

public class Sedentary extends Wagon {
    public int places = 60;
    public boolean[] freePlaces = new boolean[places];

    @Override
    public String getInfoW() {
        return "Sedentary Wagon";
    }
}
